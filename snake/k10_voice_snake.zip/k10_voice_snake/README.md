# K10 Voice Snake

Gra Snake na UNIHIKER K10 sterowana głosem: **up / down / left / right**.
Model keyword spotting (mały CNN, int8, ok. 75 KB) jest trenowany na **Google Speech Commands v2**
i działa w całości na płytce. Nie trzeba żadnych dodatkowych komponentów.

## Pliki

| Plik | Co to jest |
|---|---|
| `train_kws_k10.ipynb` | Notebook Colab: pobiera dataset, liczy cechy, trenuje, konwertuje do int8, zapisuje na Dysk Google |
| `k10_voice_snake.ino` | Szkic Arduino: mikrofon (I2S) → cechy → model → sterowanie wężem |
| `audio_features.h` | Ekstrakcja cech log-mel (49×40) – identyczna z funkcją `features()` w notebooku |
| `model_data.h` | **Generuje go notebook** – trzeba go skopiować do tego folderu |

## 1. Trening (Colab, ok. 20–40 min)

1. Otwórz `train_kws_k10.ipynb` w Colabie (File → Upload notebook).
2. Opcjonalnie włącz GPU: Runtime → Change runtime type → T4.
3. Runtime → Run all. Zezwól na dostęp do Dysku Google.
4. Wyniki trafią do `MyDrive/k10_voice_snake/`:
   - `model_data.h` – model + stałe normalizacji + etykiety
   - `model_int8.tflite`, `model.keras`
   - `training_history.png`, `confusion_matrix.png` (przydatne do sprawozdania)

Notebook wypisuje dokładność modelu float32 oraz int8 na zbiorze testowym. Spodziewany wynik to ok. 90%.

## 2. Arduino IDE

> K10 oficjalnie wspiera **Arduino IDE 1.8.19** (wersja 2.x może nie działać).

1. File → Preferences → *Additional Boards Manager URLs*:
   `https://downloadcd.dfrobot.com.cn/UNIHIKER/package_unihiker_index.json`
2. Tools → Board → Boards Manager → wyszukaj **UNIHIKER** → Install.
3. Sketch → Include Library → Manage Libraries → zainstaluj **MicroTFLite** (johnosbb).
4. Skopiuj `model_data.h` z Dysku do folderu `k10_voice_snake/`.
5. Tools: Board **UNIHIKER K10**, właściwy port, *USB CDC On Boot: Enabled*.
6. Upload. Pierwsza kompilacja trwa kilka minut.

## 3. Gra

- **Przycisk A**: start / pauza / restart po przegranej
- **Przycisk B**: przełącza prędkość węża
- **Głos**: mów wyraźnie po angielsku *up, down, left, right*, ok. 20–50 cm od płytki
- Wąż przechodzi przez ściany, bo komendy głosowe mają ~0,5 s opóźnienia
- Pasek u góry pokazuje ostatnią rozpoznaną komendę i pewność modelu

## 4. Kalibracja (Serial Monitor, 115200)

Każda inferencja wypisuje linię:
```
[KWS] up         0.91 | peak  6200 | cechy 40 ms, model 60 ms
```

| Problem | Co zmienić w `.ino` |
|---|---|
| `peak` przy mówieniu < 2000 (mikrofon za cichy) | zwiększ `MIC_GAIN` (np. 2.0–4.0) |
| `peak` często 32767 (przesterowanie) | zmniejsz `MIC_GAIN` |
| Reaguje na szumy / rozmowę w tle | podnieś `CONF_THRESHOLD` (0.8) lub `MIN_PEAK` |
| Nie reaguje mimo dobrego peak | obniż `CONF_THRESHOLD` (0.6) |
| `peak` zawsze ~0 | zmień `MIC_CHANNEL` na 1 |
| Komenda wyzwala się podwójnie | zwiększ `COMMAND_COOLDOWN_MS` |

## Jak to działa

```
mikrofon ES7243E ──I2S 16 kHz──► bufor kołowy 1 s (zadanie na rdzeniu 0)
                                       │ co 200 ms
                                       ▼
          okno Hanna 30 ms / krok 20 ms, FFT 512, 40 filtrów mel, log  → 49×40 cech
                                       ▼
                normalizacja (MEAN/STD z treningu) → kwantyzacja int8
                                       ▼
          CNN: 3× [Conv 3×3 + MaxPool] → Conv (zamiast Dense) → Softmax (6 klas)
                                       ▼
        uśrednienie z 3 ostatnich wyników + próg + cooldown → kierunek węża
```

- **Zgodność cech**: `audio_features.h` porównano z `features()` z notebooka na kilku sygnałach testowych. Wyniki są identyczne (różnica 0.0000). Jeśli zmienisz parametry w notebooku, zmień je też w `audio_features.h`. Szkic się wtedy nie skompiluje, dopóki się nie zgadzają (`static_assert`).
- **Eksport modelu**: warstwy `Flatten + Dense` są przy eksporcie zamieniane na równoważne `Conv2D`, więc graf TFLite zawiera tylko `CONV_2D`, `MAX_POOL_2D` i `SOFTMAX`.
- **Klasy**: `_silence_` (szum tła z datasetu), `_unknown_` (pozostałe słowa z datasetu), `up`, `down`, `left`, `right`.
- **Augmentacja**: przesunięcie w czasie ±100 ms, zmiana głośności 0,25–2×, domieszka szumu tła. Pomaga to przenieść model z mikrofonów z datasetu na mikrofon K10.
