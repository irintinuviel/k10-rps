// audio_features.h
// Ekstrakcja cech log-mel dla keyword spottingu (UNIHIKER K10).
// MUSI liczyć dokładnie to samo co funkcja `features()` w notebooku Colab
// (te same parametry, okno Hanna, FFT 512, banki mel HTK, log(x + eps)).
// Brak zależności od Arduino, więc da się to skompilować i przetestować na PC.
#pragma once
#include <math.h>
#include <stdint.h>
#include <string.h>

#define KWS_SAMPLE_RATE   16000
#define KWS_CLIP_SAMPLES  16000                 // 1 s audio
#define KWS_FRAME_LEN     480                   // 30 ms
#define KWS_FRAME_HOP     320                   // 20 ms
#define KWS_FFT_SIZE      512
#define KWS_NUM_BINS      (KWS_FFT_SIZE / 2 + 1) // 257
#define KWS_NUM_FRAMES    (1 + (KWS_CLIP_SAMPLES - KWS_FRAME_LEN) / KWS_FRAME_HOP) // 49
#define KWS_NUM_MELS      40
#define KWS_FMIN          60.0f
#define KWS_FMAX          7600.0f
#define KWS_LOG_EPS       1e-6f
#define KWS_NUM_FEATURES  (KWS_NUM_FRAMES * KWS_NUM_MELS) // 1960

class KwsFeatures {
 public:
  void begin() {
    // Okno Hanna (symetryczne) - identyczne jak w notebooku.
    for (int n = 0; n < KWS_FRAME_LEN; n++) {
      window_[n] = 0.5f - 0.5f * cosf(2.0f * (float)M_PI * n / (KWS_FRAME_LEN - 1));
    }
    // Tablice FFT.
    int bits = 0;
    while ((1 << bits) < KWS_FFT_SIZE) bits++;
    for (int i = 0; i < KWS_FFT_SIZE; i++) {
      int r = 0;
      for (int b = 0; b < bits; b++) r |= ((i >> b) & 1) << (bits - 1 - b);
      bitrev_[i] = (uint16_t)r;
    }
    for (int k = 0; k < KWS_FFT_SIZE / 2; k++) {
      twCos_[k] = cosf(2.0f * (float)M_PI * k / KWS_FFT_SIZE);
      twSin_[k] = -sinf(2.0f * (float)M_PI * k / KWS_FFT_SIZE);
    }
    buildMelFilterbank();
  }

  // clip: KWS_CLIP_SAMPLES próbek int16 (najstarsza pierwsza)
  // out:  KWS_NUM_FRAMES x KWS_NUM_MELS (wierszami po ramkach), log-mel BEZ normalizacji
  void compute(const int16_t* clip, float* out) {
    // Usunięcie składowej stałej z całego klipu (jak x - x.mean() w Pythonie).
    double sum = 0.0;
    for (int i = 0; i < KWS_CLIP_SAMPLES; i++) sum += clip[i];
    const float dc = (float)(sum / KWS_CLIP_SAMPLES) / 32768.0f;

    for (int f = 0; f < KWS_NUM_FRAMES; f++) {
      const int16_t* frame = clip + f * KWS_FRAME_HOP;
      for (int n = 0; n < KWS_FRAME_LEN; n++) {
        re_[n] = (frame[n] / 32768.0f - dc) * window_[n];
        im_[n] = 0.0f;
      }
      for (int n = KWS_FRAME_LEN; n < KWS_FFT_SIZE; n++) { re_[n] = 0.0f; im_[n] = 0.0f; }
      fft();
      for (int k = 0; k < KWS_NUM_BINS; k++) power_[k] = re_[k] * re_[k] + im_[k] * im_[k];

      float* row = out + f * KWS_NUM_MELS;
      for (int m = 0; m < KWS_NUM_MELS; m++) {
        float acc = 0.0f;
        const float* w = melW_ + melOff_[m];
        const int start = melStart_[m];
        for (int j = 0; j < melLen_[m]; j++) acc += power_[start + j] * w[j];
        row[m] = logf(acc + KWS_LOG_EPS);
      }
    }
  }

 private:
  static float hzToMel(float f) { return 2595.0f * log10f(1.0f + f / 700.0f); }
  static float melToHz(float m) { return 700.0f * (powf(10.0f, m / 2595.0f) - 1.0f); }

  void buildMelFilterbank() {
    float hz[KWS_NUM_MELS + 2];
    const float mMin = hzToMel(KWS_FMIN), mMax = hzToMel(KWS_FMAX);
    for (int i = 0; i < KWS_NUM_MELS + 2; i++) {
      hz[i] = melToHz(mMin + (mMax - mMin) * i / (KWS_NUM_MELS + 1));
    }
    int off = 0;
    for (int m = 0; m < KWS_NUM_MELS; m++) {
      const float l = hz[m], c = hz[m + 1], r = hz[m + 2];
      int start = -1, len = 0;
      for (int k = 0; k < KWS_NUM_BINS; k++) {
        const float fk = (float)k * KWS_SAMPLE_RATE / KWS_FFT_SIZE;
        float up = (fk - l) / (c - l);
        float down = (r - fk) / (r - c);
        float w = up < down ? up : down;
        if (w > 0.0f) {
          if (start < 0) start = k;
          if (off + len < kMaxMelWeights) melW_[off + len] = w;
          len++;
        }
      }
      if (start < 0) { start = 0; len = 0; }  // pusty filtr -> log(eps), tak samo jak w numpy
      melStart_[m] = (uint16_t)start;
      melLen_[m] = (uint16_t)len;
      melOff_[m] = (uint16_t)off;
      off += len;
    }
  }

  void fft() {
    for (int i = 0; i < KWS_FFT_SIZE; i++) {
      int j = bitrev_[i];
      if (j > i) {
        float t = re_[i]; re_[i] = re_[j]; re_[j] = t;
        t = im_[i]; im_[i] = im_[j]; im_[j] = t;
      }
    }
    for (int len = 2; len <= KWS_FFT_SIZE; len <<= 1) {
      const int half = len >> 1;
      const int step = KWS_FFT_SIZE / len;
      for (int i = 0; i < KWS_FFT_SIZE; i += len) {
        for (int k = 0; k < half; k++) {
          const float wr = twCos_[k * step], wi = twSin_[k * step];
          const int a = i + k, b = a + half;
          const float tr = re_[b] * wr - im_[b] * wi;
          const float ti = re_[b] * wi + im_[b] * wr;
          re_[b] = re_[a] - tr; im_[b] = im_[a] - ti;
          re_[a] += tr;         im_[a] += ti;
        }
      }
    }
  }

  static const int kMaxMelWeights = 1024;
  float window_[KWS_FRAME_LEN];
  float re_[KWS_FFT_SIZE], im_[KWS_FFT_SIZE];
  float power_[KWS_NUM_BINS];
  float twCos_[KWS_FFT_SIZE / 2], twSin_[KWS_FFT_SIZE / 2];
  uint16_t bitrev_[KWS_FFT_SIZE];
  float melW_[kMaxMelWeights];
  uint16_t melStart_[KWS_NUM_MELS], melLen_[KWS_NUM_MELS], melOff_[KWS_NUM_MELS];
};
